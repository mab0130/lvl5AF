=== Bulk Categories Edit for Media ===
Contributors: tomasbulva
Donate link: 
Tags: categories, media, bulk, edit, bulk edit
Requires at least: 3.5
Tested up to: 3.5.1
Stable tag: 1.0

== Description ==

Allows to edit categories in bulk at attachement/media page, needs to have categories for media enabled.

== Installation ==

1. Upload `custom_bulk_edit_categories_in_media` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Plugin depends on categories for media to be enabled. For witch is needed the 3rd party plugin.
3. Access plugin UI thru bulk edit drop down on the media admin screen.

== Changelog ==
= 1.0 =
* 2013-02-02: Initial release
