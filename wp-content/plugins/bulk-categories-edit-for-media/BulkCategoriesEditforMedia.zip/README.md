Wordpress-Bulk-Categories-Edit-for-Media
==========================================

Allows to edit categories in bulk at attachement/media page, needs to have categories for media enabled.

designed for wordpress 3.5+